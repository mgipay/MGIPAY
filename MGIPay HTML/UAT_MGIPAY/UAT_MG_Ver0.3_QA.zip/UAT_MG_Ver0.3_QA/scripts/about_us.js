// JavaScript Document
$(document).ready(function() {
	$("#headerNav a:eq(0)").click(function() {
		window.location.href = "FAQS.html";
	});
	$("#headerNav a:eq(1)").click(function() {
		window.location.href = "contactus.html";
	});
	$("#headerNav a:eq(2)").click(function() {
		window.location.href = "history.html";
	});
	$("#home").click(function() {
		window.location.href = "home.html";
	});
	$("#footerNav a:eq(0)").click(function() {
		window.location.href = "termsofuse.html";
	});
	$("#terms_conditions").click(function() {
		window.location.href = "terms_conditions.html";
	});
	$("#aboutmoneygram").click(function() {
		window.location.href = "aboutmoneygram.html";
	});
	$("#privacypolicy").click(function() {
		window.location.href = "privacypolicy.html";
	});
});

