
var resources = {
	'country' : 'United States',
	'availableTime' : '10 Minutes',
	'errorMsg' : 'An error has occurred while processing. Please try again. If you continue to receive this error, contact MoneyGram at 1-800-MONEYGRAM. Thank you.',
	'validAmt' : 'Please enter valid receive amount',
	'validLocation' : 'Please select Pick Up Location',
	'selectState' : 'Select your state',
	'user' : 'MGI',
	'firstNameMsg' : 'Please enter first name properly',
	'lastNameMsg' : 'Please enter last name properly',
	'emailMsg' : 'Please enter valid email address',
	'PhoneNumMsg' : 'Please enter valid Phone number',
	'msgContactUs' : 'Please enter Message',
	'zipcodeMsg' : 'Zipcode length should be greater than 4'
	
	}
